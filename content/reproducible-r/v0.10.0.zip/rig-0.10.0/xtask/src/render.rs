//! Minimal Markdown -> ANSI renderer for rig's `--help` text.
//!
//! The help prose for each command lives in a Markdown file under `src/help/`.
//! This renders that Markdown to the colored, indented text clap shows for
//! `--help`. The supported subset is small on purpose -- headings, paragraphs,
//! bullet/ordered lists, inline `code`, **bold**, *italic* and fenced code
//! blocks -- which is all the help text uses. The same Markdown files are
//! included verbatim by the documentation website, where Quarto renders them to
//! HTML.
//!
//! Rendering happens here, in the dev-only `xtask` crate, at generation time;
//! the output is committed to `src/help-generated.in`, so `--help` pays no
//! rendering cost at run time. clap strips the ANSI on non-terminal output,
//! exactly as it did for the previous hand-written strings.

use pulldown_cmark::{Event, Options, Parser, Tag, TagEnd};

// Indentation (in spaces) of block content under a section heading.
const HELP_INDENT: usize = 2;

// The kind of the most recently emitted block, used to decide how much
// vertical space to put before the next one.
#[derive(PartialEq, Clone, Copy)]
enum HelpBlock {
    Heading,
    Item,
    Other,
}

// Render Markdown to ANSI. `color` is always true for the generated help
// strings; clap removes the escapes when the output is not a terminal.
pub(crate) fn md_to_ansi_impl(md: &str, color: bool) -> String {
    let parser = Parser::new_ext(md, Options::empty());

    let mut out = String::new();
    // Inline content of the current block, with embedded '\n' for line breaks.
    let mut inline = String::new();
    // Stack of list counters: None for a bullet list, Some(n) for the next
    // number in an ordered list.
    let mut lists: Vec<Option<u64>> = Vec::new();
    // Stack of open list items: None until the item's marker has been emitted,
    // Some(width) afterwards, so that the further paragraphs of a loose item
    // line up with the first one instead of getting a second marker.
    let mut items: Vec<Option<usize>> = Vec::new();
    let mut in_code_block = false;
    let mut last: Option<HelpBlock> = None;

    // Separator before the next block: nothing for the first block, a single
    // newline after a heading or between list items, otherwise a blank line.
    let sep = |out: &mut String, last: Option<HelpBlock>, cur: HelpBlock| match last {
        None => {}
        Some(HelpBlock::Heading) => out.push('\n'),
        Some(HelpBlock::Item) if cur == HelpBlock::Item => out.push('\n'),
        _ => out.push_str("\n\n"),
    };

    // Emit `text` (which may contain '\n') with `prefix` on the first line and
    // `cont` on every following line. Blank lines are left empty rather than
    // padded with trailing whitespace.
    let emit = |out: &mut String, text: &str, prefix: &str, cont: &str| {
        for (i, line) in text.split('\n').enumerate() {
            let pad = if i == 0 { prefix } else { cont };
            if i > 0 {
                out.push('\n');
            }
            if !line.is_empty() {
                out.push_str(pad);
                out.push_str(line);
            }
        }
    };

    // Emit the text of a list item: the first block of the item carries the
    // bullet or the number, the further blocks of a loose item are indented to
    // line up under it.
    let emit_item = |out: &mut String,
                     text: &str,
                     lists: &mut Vec<Option<u64>>,
                     items: &mut Vec<Option<usize>>,
                     last: Option<HelpBlock>| {
        sep(out, last, HelpBlock::Item);
        let (prefix, cont) = match items.last() {
            Some(Some(width)) => (" ".repeat(*width), " ".repeat(*width)),
            _ => {
                let depth = lists.len().max(1);
                let marker = match lists.last_mut() {
                    Some(Some(n)) => {
                        let m = format!("{}. ", *n);
                        *n += 1;
                        m
                    }
                    _ => "- ".to_string(),
                };
                let prefix = format!("{}{}", " ".repeat(HELP_INDENT * depth), marker);
                let width = prefix.chars().count();
                if let Some(state) = items.last_mut() {
                    *state = Some(width);
                }
                (prefix, " ".repeat(width))
            }
        };
        emit(out, text, &prefix, &cont);
    };

    for (ev, range) in parser.into_offset_iter() {
        match ev {
            // -- block starts ---------------------------------------------
            Event::Start(Tag::Heading { .. }) | Event::Start(Tag::Paragraph) => {
                inline.clear();
            }
            Event::Start(Tag::List(start)) => {
                lists.push(start);
            }
            Event::Start(Tag::Item) => {
                inline.clear();
                items.push(None);
            }
            Event::Start(Tag::CodeBlock(_)) => {
                in_code_block = true;
                inline.clear();
            }

            // -- block ends -----------------------------------------------
            Event::End(TagEnd::Heading(_)) => {
                sep(&mut out, last, HelpBlock::Heading);
                let text = format!("{}:", inline.trim_end());
                if color {
                    out.push_str("\x1b[1m\x1b[34m");
                    out.push_str(&text);
                    out.push_str("\x1b[39m\x1b[22m");
                } else {
                    out.push_str(&text);
                }
                last = Some(HelpBlock::Heading);
            }
            // The paragraphs of a loose list item belong to the item, not to
            // the enclosing block, so they get the item's indentation. Their
            // blocks are separated by a blank line, like any other paragraph,
            // which is also what puts a blank line between loose items.
            Event::End(TagEnd::Paragraph) => {
                if items.is_empty() {
                    sep(&mut out, last, HelpBlock::Other);
                    let indent = " ".repeat(HELP_INDENT);
                    emit(&mut out, inline.trim_end(), &indent, &indent);
                } else {
                    emit_item(&mut out, inline.trim_end(), &mut lists, &mut items, last);
                }
                inline.clear();
                last = Some(HelpBlock::Other);
            }
            // A tight list item carries its text directly; in a loose list the
            // paragraph above has already emitted it, leaving nothing here.
            Event::End(TagEnd::Item) => {
                if !inline.trim_end().is_empty() {
                    emit_item(&mut out, inline.trim_end(), &mut lists, &mut items, last);
                    inline.clear();
                    last = Some(HelpBlock::Item);
                }
                items.pop();
            }
            Event::End(TagEnd::List(_)) => {
                lists.pop();
            }
            Event::End(TagEnd::CodeBlock) => {
                sep(&mut out, last, HelpBlock::Other);
                let indent = " ".repeat(HELP_INDENT);
                emit(&mut out, inline.trim_end_matches('\n'), &indent, &indent);
                in_code_block = false;
                inline.clear();
                last = Some(HelpBlock::Other);
            }

            // -- inline content -------------------------------------------
            Event::Text(t) => inline.push_str(&t),
            Event::Code(t) => {
                if in_code_block {
                    inline.push_str(&t);
                } else {
                    // pulldown-cmark collapses a line ending inside a code
                    // span into a single space per CommonMark, losing the
                    // wrap point the author put there. Recover it from the
                    // raw source so it survives as a real line break, like a
                    // SoftBreak between two Text events, wherever the span
                    // was actually wrapped across source lines.
                    let raw = &md[range.clone()];
                    let backticks = raw.chars().take_while(|&c| c == '`').count();
                    let content = &raw[backticks..raw.len() - backticks];
                    let text = if content.contains(['\n', '\r']) {
                        content.replace("\r\n", "\n").replace('\r', "\n")
                    } else {
                        t.to_string()
                    };
                    if color {
                        inline.push_str("\x1b[32m");
                        inline.push_str(&text);
                        inline.push_str("\x1b[39m");
                    } else {
                        inline.push('`');
                        inline.push_str(&text);
                        inline.push('`');
                    }
                }
            }
            Event::Start(Tag::Strong) | Event::End(TagEnd::Strong) if color => {
                inline.push_str(if matches!(ev, Event::Start(_)) {
                    "\x1b[1m"
                } else {
                    "\x1b[22m"
                });
            }
            Event::Start(Tag::Emphasis) | Event::End(TagEnd::Emphasis) if color => {
                inline.push_str(if matches!(ev, Event::Start(_)) {
                    "\x1b[3m"
                } else {
                    "\x1b[23m"
                });
            }
            Event::SoftBreak | Event::HardBreak => inline.push('\n'),

            _ => {}
        }
    }

    out
}

// Render a short, single-paragraph Markdown snippet to ANSI *without* any block
// formatting -- no heading treatment and no leading indentation. Used for the
// one-line command summary (`about`), which clap lays out in its own subcommand
// table, so it must not carry the 2-space paragraph indent `md_to_ansi_impl`
// adds. Inline `code`, **bold** and *italic* are still colored; soft/hard line
// breaks collapse to single spaces.
pub(crate) fn md_to_ansi_inline(md: &str, color: bool) -> String {
    let parser = Parser::new_ext(md, Options::empty());
    let mut out = String::new();
    for ev in parser {
        match ev {
            Event::Text(t) => out.push_str(&t),
            Event::Code(t) => {
                if color {
                    out.push_str("\x1b[32m");
                    out.push_str(&t);
                    out.push_str("\x1b[39m");
                } else {
                    out.push('`');
                    out.push_str(&t);
                    out.push('`');
                }
            }
            Event::Start(Tag::Strong) | Event::End(TagEnd::Strong) if color => {
                out.push_str(if matches!(ev, Event::Start(_)) {
                    "\x1b[1m"
                } else {
                    "\x1b[22m"
                });
            }
            Event::Start(Tag::Emphasis) | Event::End(TagEnd::Emphasis) if color => {
                out.push_str(if matches!(ev, Event::Start(_)) {
                    "\x1b[3m"
                } else {
                    "\x1b[23m"
                });
            }
            Event::SoftBreak | Event::HardBreak => out.push(' '),
            _ => {}
        }
    }
    out.trim().to_string()
}

#[cfg(test)]
mod tests {
    use super::{md_to_ansi_impl, md_to_ansi_inline};

    #[test]
    fn plain_heading_and_paragraph() {
        let md = "## Description\n\nHello `world` and more.";
        assert_eq!(
            md_to_ansi_impl(md, false),
            "Description:\n  Hello `world` and more."
        );
    }

    #[test]
    fn color_heading_and_code() {
        let md = "## Description\n\nUse `R`.";
        assert_eq!(
            md_to_ansi_impl(md, true),
            "\x1b[1m\x1b[34mDescription:\x1b[39m\x1b[22m\n  Use \x1b[32mR\x1b[39m."
        );
    }

    #[test]
    fn bullet_list_indentation() {
        let md = "## D\n\nWays:\n\n- first item that is\n  wrapped onto two lines\n- second";
        assert_eq!(
            md_to_ansi_impl(md, false),
            "D:\n  Ways:\n\n  - first item that is\n    wrapped onto two lines\n  - second"
        );
    }

    // A blank line between the items makes the list loose, i.e. each item's
    // text is a paragraph. It must still be emitted once, with the marker, and
    // a further paragraph of the same item lines up under the first one.
    #[test]
    fn loose_list_items_are_not_duplicated() {
        let md = "- first item\n\n- second item\n\n  more about the second";
        assert_eq!(
            md_to_ansi_impl(md, false),
            "  - first item\n\n  - second item\n\n    more about the second"
        );
    }

    #[test]
    fn ordered_list_numbers() {
        let md = "1. one\n2. two";
        assert_eq!(md_to_ansi_impl(md, false), "  1. one\n  2. two");
    }

    #[test]
    fn code_block_is_indented() {
        let md = "Run:\n\n```sh\nrig add devel\n```";
        assert_eq!(md_to_ansi_impl(md, false), "  Run:\n\n  rig add devel");
    }

    #[test]
    fn markdown_link_keeps_text_drops_url() {
        // Markdown links are the general "web link" mechanism for help files:
        // the website renders them as real links, while `--help` shows only the
        // link text (the URL is dropped). Wrapping existing words in a link
        // therefore leaves the ANSI output byte-for-byte unchanged.
        let md = "Switch to [user mode](../articles/admin-vs-user-mode.qmd) first.";
        assert_eq!(md_to_ansi_impl(md, false), "  Switch to user mode first.");
        // Inline `code` inside the link text is still rendered.
        let md = "See [`rig`](rig.qmd) help.";
        assert_eq!(md_to_ansi_impl(md, false), "  See `rig` help.");
    }

    #[test]
    fn inline_markdown_link_keeps_text_drops_url() {
        assert_eq!(
            md_to_ansi_inline("Run in [user mode](x.qmd)", false),
            "Run in user mode"
        );
    }

    #[test]
    fn wrapped_code_span_keeps_line_break() {
        let md = "Run `rig\nsystem dirs` now.";
        assert_eq!(
            md_to_ansi_impl(md, false),
            "  Run `rig\n  system dirs` now."
        );
        assert_eq!(
            md_to_ansi_impl(md, true),
            "  Run \x1b[32mrig\n  system dirs\x1b[39m now."
        );
    }

    #[test]
    fn inline_has_no_indent_and_collapses_breaks() {
        let md = "List installed R versions\n[alias: `ls`]";
        assert_eq!(
            md_to_ansi_inline(md, false),
            "List installed R versions [alias: `ls`]"
        );
        assert_eq!(
            md_to_ansi_inline("Use `R`.", true),
            "Use \x1b[32mR\x1b[39m."
        );
    }
}
