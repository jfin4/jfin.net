use regex::Regex;
use std::error::Error;
use std::path::{Path, PathBuf};

use globset::Glob;
use log::{debug, error, warn};
use simple_error::*;

use crate::common::*;
use crate::dcf::*;
use crate::hardcoded::*;
use crate::output::OUTPUT;
use crate::repositories::*;
use crate::utils::*;

use super::{
    config::{get_repos_config, Enabled, RepoEntry, Repository},
    interpret_repos_args::ReposSetupArgs,
};

#[cfg(target_os = "macos")]
use crate::macos::*;

#[cfg(target_os = "windows")]
use crate::windows::*;

#[cfg(target_os = "linux")]
use crate::linux::*;

#[cfg(target_os = "linux")]
use crate::platform::*;

#[derive(Debug)]
struct RData {
    pub platform: String,
    pub arch: String,    // x86_64, aarch64
    pub version: String, // 4.5.2, etc.
    pub distro: Option<String>,
    pub release: Option<String>,
}

fn validate_repos_in_setup(
    config: &[Repository],
    setup: &ReposSetupArgs,
) -> Result<(), Box<dyn Error>> {
    let mut valid_repo_names: Vec<String> = config
        .iter()
        .map(|r| r.name.to_lowercase())
        .collect::<Vec<_>>();
    valid_repo_names.sort();

    let mut invalid_repos: Vec<String> = Vec::new();

    match setup {
        ReposSetupArgs::Default {
            whitelist,
            blacklist,
        } => {
            for repo in whitelist.iter().chain(blacklist.iter()) {
                if !valid_repo_names.contains(repo) {
                    invalid_repos.push(repo.clone());
                }
            }
        }
        ReposSetupArgs::Empty { whitelist } => {
            for repo in whitelist.iter() {
                if !valid_repo_names.contains(repo) {
                    invalid_repos.push(repo.clone());
                }
            }
        }
    }

    if !invalid_repos.is_empty() {
        invalid_repos.sort();
        invalid_repos.dedup();
        let inv = invalid_repos.join(", ");
        let val = valid_repo_names.join(", ");
        let msg = format!(
            "Invalid repository name(s): {}. Valid repositories are: {}",
            inv, val
        );
        OUTPUT.error(&msg);
        error!("{}", msg);
        bail!("{}", msg);
    }

    Ok(())
}

pub fn repos_setup(vers: Option<Vec<String>>, setup: ReposSetupArgs) -> Result<(), Box<dyn Error>> {
    let vers = match vers {
        Some(v) => v,
        None => sc_get_list()?,
    };
    let config = get_repos_config()?;

    // Validate that all repositories in whitelist and blacklist exist in config
    validate_repos_in_setup(&config, &setup)?;

    for ver in vers {
        let ver = check_installed(&ver.to_string())?;
        let root: String = get_r_root_for(&ver)?;
        let repositories = root.clone()
            + "/"
            + &get_r_etc_path()?.replace("{}", &version_dir_key(&ver))
            + "/repositories";

        // if no 'repositories' file, skip. Maybe this happens for very old R versions?
        if !PathBuf::from(&repositories).exists() {
            debug!(
                "repositories file does not exist at {}, skipping",
                repositories
            );
            continue;
        }

        // save a copy of the original file, so we can restore later if needed.
        let orig: String = repositories.clone() + ".orig";
        if !PathBuf::from(&orig).exists() {
            debug!(
                "Original repositories file does not exist at {}, copying from {}",
                orig, repositories
            );
            std::fs::copy(&repositories, &orig)?;
        }

        debug!("Updating repositories file at {}", repositories);
        let mut repos = read_repositories_file(&orig)?;

        let rdata = get_r_data(&ver)?;
        debug!("Detected architecture {:?}", rdata);

        let rdata_platform = rdata_platform_string(&rdata);

        add_repositories_comment(&mut repos, "start added by rig");
        for repo in config.iter() {
            for entry in repo.repos.iter() {
                // An entry's `enabled` (if present) overrides the repo's. Whether
                // a repo is enabled by default can depend on the installation's
                // platform (e.g. P3M-manylinux is a default only on manylinux).
                let enabled = entry.enabled.as_ref().unwrap_or(&repo.enabled);
                let enabled_default = enabled_by_default(enabled, &rdata_platform, &repo.name);
                if !should_include_repo(&setup, &repo.name, enabled_default) {
                    continue;
                }
                if !should_activate_repo(repo, entry, &rdata)? {
                    continue;
                }
                add_repository(&mut repos, entry);
            }
        }
        add_repositories_comment(&mut repos, "end added by rig");

        write_repositories_file(repos, &repositories)?;

        let profile =
            root.clone() + "/" + &get_r_base_profile()?.replace("{}", &version_dir_key(&ver));
        debug!("Updating R profile at {}", profile);
        let mut profile_lines = read_lines(Path::new(&profile))?;

        // maybe already current?
        if !grep_lines(
            &Regex::new(&HC_PROFILE_REPOS_MARKERS.current_start.to_string())?,
            &profile_lines,
        )
        .is_empty()
        {
            continue;
        }

        // maybe from another version of rig?
        let start = grep_lines(
            &Regex::new(&HC_PROFILE_REPOS_MARKERS.generic_start.to_string())?,
            &profile_lines,
        );
        let end = grep_lines(
            &Regex::new(&HC_PROFILE_REPOS_MARKERS.end.to_string())?,
            &profile_lines,
        );

        if start.len() == 1 && end.len() == 1 {
            // remove old version
            profile_lines.drain(start[0]..=end[0]);
        } else if start.is_empty() && end.is_empty() {
            // nothing there, nothing to remove
        } else {
            OUTPUT.warn(&format!(
                "Corrupt R profile at {}, try reinstalling R. If the issue perists, report it to rig developers.",
                profile
            ));
            warn!("Corrupt R profile at {}, try reinstalling R. If the issue perists, report it to rig developers.", profile);
            continue;
        }

        profile_lines.push(HC_PROFILE_REPOS.to_string());
        std::fs::write(&profile, profile_lines.join("\n"))?;
    }

    Ok(())
}

// Compose the full platform string that platform globs are matched against,
// e.g. "x86_64-pc-linux-gnu-ubuntu-22.04" or "x86_64-pc-linux-gnu-manylinux-2.34".
fn rdata_platform_string(rdata: &RData) -> String {
    let mut platform = rdata.platform.clone();
    if let Some(p) = &rdata.distro {
        platform += "-";
        platform += p;
    }
    if let Some(r) = &rdata.release {
        platform += "-";
        platform += r;
    }
    platform
}

// Whether `rdata_platform` matches any of the given platform globs. Invalid
// globs are warned about and skipped. `ctx` is the repo name, for messages.
fn platform_matches_any(platforms: &[String], rdata_platform: &str, ctx: &str) -> bool {
    for platform in platforms.iter() {
        let glob = match Glob::new(platform) {
            Ok(g) => g.compile_matcher(),
            Err(e) => {
                OUTPUT.warn(&format!(
                    "Invalid platform glob '{}' in repo '{}', skipping: {}",
                    platform, ctx, e
                ));
                warn!(
                    "Invalid platform glob '{}' in repo '{}', skipping: {}",
                    platform, ctx, e
                );
                continue;
            }
        };
        if glob.is_match(rdata_platform) {
            debug!("Repo '{}' matches platform glob '{}'", ctx, platform);
            return true;
        }
    }
    false
}

// Whether a repo/entry with this `enabled` setting is enabled by default for the
// given (composed) platform string.
fn enabled_by_default(enabled: &Enabled, rdata_platform: &str, ctx: &str) -> bool {
    match enabled {
        Enabled::Always(b) => *b,
        Enabled::OnPlatforms { platforms } => platform_matches_any(platforms, rdata_platform, ctx),
    }
}

// Whether `repo_name` should be added at all, given the whitelist/blacklist
// setup and whether it's enabled by default. A blacklisted repo is always
// excluded, even if it would otherwise be enabled by default.
fn should_include_repo(setup: &ReposSetupArgs, repo_name: &str, enabled_default: bool) -> bool {
    let repo_name = repo_name.to_lowercase();
    match setup {
        ReposSetupArgs::Default {
            whitelist,
            blacklist,
        } => {
            if blacklist.contains(&repo_name) {
                return false;
            }
            enabled_default || whitelist.contains(&repo_name)
        }
        ReposSetupArgs::Empty { whitelist } => whitelist.contains(&repo_name),
    }
}

fn should_activate_repo(
    repo: &Repository,
    entry: &RepoEntry,
    rdata: &RData,
) -> Result<bool, Box<dyn Error>> {
    debug!(
        "Checking if repo '{}' should be activated for platform '{}', arch '{}', R version '{}'",
        repo.name, rdata.platform, rdata.arch, rdata.version
    );

    // if platforms are present, then they must match the current platform
    if let Some(platforms) = &entry.platforms {
        let rdata_platform = rdata_platform_string(rdata);
        if !platform_matches_any(platforms, &rdata_platform, &repo.name) {
            debug!(
                "Repo '{}' (platform {}) does not match any platform glob, skipping",
                repo.name, rdata_platform
            );
            return Ok(false);
        }
    }

    // if archs are present, then they must match the current arch
    if let Some(archs) = &entry.archs {
        let mut ok = false;
        for arch in archs.iter() {
            if arch == &rdata.arch {
                debug!("Repo '{}' matches arch '{}'", repo.name, arch);
                ok = true;
                break;
            }
        }
        if !ok {
            return Ok(false);
        }
    }

    // if rversions are present, then one of them must be satisfied by the current R version
    if let Some(rversions) = &entry.rversions {
        let mut ok = false;
        for constraint in rversions.iter() {
            let depconstraint = VersionConstraint::from_str(constraint)?;
            let dep = DepVersionSpec {
                name: "R".to_string(),
                types: vec![RDepType::Depends],
                constraints: vec![depconstraint],
            };
            if dep.satisfies(&rdata.version)? {
                debug!(
                    "Repo '{}' (R {}) matches R version constraint '{}'",
                    repo.name, rdata.version, constraint
                );
                ok = true;
                break;
            }
        }
        if !ok {
            return Ok(false);
        }
    }

    Ok(true)
}

#[cfg(target_os = "macos")]
fn get_r_data(ver: &str) -> Result<RData, Box<dyn Error>> {
    get_r_data_common(ver)
}

fn get_r_data_common(ver: &str) -> Result<RData, Box<dyn Error>> {
    let root: String = get_r_root_for(ver)?;
    let statsdesc = root
        + "/"
        + &get_r_syslibpath()?.replace("{}", &version_dir_key(ver))
        + "/stats/DESCRIPTION";
    debug!("Getting architectture from {}.", statsdesc);
    let lines = read_lines(Path::new(&statsdesc))?;
    let re = Regex::new("^Built:[ ]?")?;
    let bltidx = grep_lines(&re, &lines);
    if bltidx.is_empty() {
        OUTPUT.error(&format!(
            "Could not find 'Built' field in {}, cannot determine architecture of R installation.",
            statsdesc
        ));
        error!(
            "Could not find 'Built' field in {}, cannot determine architecture of R installation.",
            statsdesc
        );
        bail!(
            "Could not find 'Built' in {}, cannot determine architecture of R installation.",
            statsdesc
        );
    }
    let blt = &lines[bltidx[0]];

    // Remove "Built:" prefix and split by semicolons
    let built = blt.strip_prefix("Built:").unwrap_or(blt).trim();
    let parts: Vec<&str> = built.split(';').collect();

    if parts.len() < 2 {
        OUTPUT.error(&format!(
            "Could not parse 'Built' field in {}, unexpected format: {}",
            statsdesc, blt
        ));
        error!(
            "Could not parse 'Built' field in {}, unexpected format: {}",
            statsdesc, blt
        );
        bail!("Could not parse 'Built' field in {}: {}", statsdesc, blt);
    }

    let platform = parts[1].trim();
    let parts2: Vec<&str> = platform.splitn(3, '-').collect();
    if parts2.len() < 3 {
        OUTPUT.error(&format!(
            "Could not parse 'Built' field in {}, unexpected platform format: {}",
            statsdesc, platform
        ));
        error!(
            "Could not parse 'Built' field in {}, unexpected platform format: {}",
            statsdesc, platform
        );
        bail!("Could not parse 'Built' field in {}: {}", statsdesc, blt);
    }

    let arch = parts2[0];

    if arch.is_empty() {
        OUTPUT.error(&format!(
            "Could not parse 'Built' field in {}, missing architecture: {}",
            statsdesc, blt,
        ));
        error!(
            "Could not parse 'Built' field in {}, missing architecture: {}",
            statsdesc, blt
        );
        bail!("Could not parse 'Built' field in {}: {}", statsdesc, blt);
    }

    let rver = parts[0].trim();
    let rver = rver.strip_prefix("R").unwrap_or(rver).trim();

    Ok(RData {
        platform: platform.to_string(),
        arch: arch.to_string(),
        version: rver.to_string(),
        distro: None,
        release: None,
    })
}

#[cfg(target_os = "linux")]
fn get_r_data(ver: &str) -> Result<RData, Box<dyn Error>> {
    let mut data = get_r_data_common(ver)?;

    let install_dir = PathBuf::from(get_r_root_for(ver)?).join(version_dir_key(ver));
    match read_install_platform(&install_dir) {
        Some(platform) => {
            debug!("Installation {} has recorded platform {}", ver, platform);
            let parts: Vec<&str> = platform.splitn(3, '-').collect();
            if parts.len() == 3 {
                data.distro = Some(parts[1].to_string());
                data.release = Some(parts[2].to_string());
            }
        }
        None => {
            debug!(
                "Installation {} has no metadata.json platform, detecting host distro",
                ver
            );
            let os = detect_platform()?;
            data.distro = os.distro;
            data.release = os.version;
        }
    }
    Ok(data)
}

#[cfg(target_os = "windows")]
fn get_r_data(ver: &str) -> Result<RData, Box<dyn Error>> {
    // TODO: this arch does not work on Windows, because of an R bug:
    // https://bugs.r-project.org/show_bug.cgi?id=19003
    // We need to look for "^BINPREF" in a a Makeconf file, in
    // etc/Makeconf, etc/x64/Makeconf or etc/i386/Makeconf.
    // If this has 'aarch64' then it is an aaarch64 R build.
    get_r_data_common(ver)
}

#[cfg(test)]
mod tests {
    use super::{
        enabled_by_default, rdata_platform_string, should_activate_repo, should_include_repo,
        validate_repos_in_setup, RData,
    };
    use crate::repos::config::{Enabled, RepoEntry, Repository};
    use crate::repos::interpret_repos_args::ReposSetupArgs;

    fn make_repo(name: &str) -> Repository {
        Repository {
            name: name.to_string(),
            title: None,
            description: None,
            enabled: Enabled::Always(true),
            repos: vec![],
        }
    }

    fn make_entry() -> RepoEntry {
        RepoEntry {
            name: "test".to_string(),
            title: None,
            description: None,
            url: "https://example.com".to_string(),
            platforms: None,
            archs: None,
            rversions: None,
            enabled: None,
        }
    }

    fn rdata(platform: &str, arch: &str, version: &str) -> RData {
        RData {
            platform: platform.to_string(),
            arch: arch.to_string(),
            version: version.to_string(),
            distro: None,
            release: None,
        }
    }

    // --- validate_repos_in_setup ---

    #[test]
    fn validate_all_valid_names() {
        let config = vec![make_repo("CRAN"), make_repo("P3M")];
        let setup = ReposSetupArgs::Default {
            whitelist: vec!["cran".to_string()],
            blacklist: vec!["p3m".to_string()],
        };
        assert!(validate_repos_in_setup(&config, &setup).is_ok());
    }

    #[test]
    fn validate_invalid_whitelist_errors() {
        let config = vec![make_repo("CRAN")];
        let setup = ReposSetupArgs::Default {
            whitelist: vec!["bioc".to_string()],
            blacklist: vec![],
        };
        assert!(validate_repos_in_setup(&config, &setup).is_err());
    }

    #[test]
    fn validate_invalid_blacklist_errors() {
        let config = vec![make_repo("CRAN")];
        let setup = ReposSetupArgs::Default {
            whitelist: vec![],
            blacklist: vec!["p3m".to_string()],
        };
        assert!(validate_repos_in_setup(&config, &setup).is_err());
    }

    #[test]
    fn validate_empty_lists_ok() {
        let config = vec![make_repo("CRAN")];
        let setup = ReposSetupArgs::Default {
            whitelist: vec![],
            blacklist: vec![],
        };
        assert!(validate_repos_in_setup(&config, &setup).is_ok());
    }

    #[test]
    fn validate_empty_setup_valid_name_ok() {
        let config = vec![make_repo("CRAN")];
        let setup = ReposSetupArgs::Empty {
            whitelist: vec!["cran".to_string()],
        };
        assert!(validate_repos_in_setup(&config, &setup).is_ok());
    }

    #[test]
    fn validate_empty_setup_invalid_name_errors() {
        let config = vec![make_repo("CRAN")];
        let setup = ReposSetupArgs::Empty {
            whitelist: vec!["bioc".to_string()],
        };
        assert!(validate_repos_in_setup(&config, &setup).is_err());
    }

    // --- should_activate_repo ---

    #[test]
    fn activate_no_constraints_returns_true() {
        let repo = make_repo("Test");
        let entry = make_entry();
        assert!(should_activate_repo(&repo, &entry, &rdata("linux", "x86_64", "4.4.0")).unwrap());
    }

    #[test]
    fn activate_platform_glob_matches() {
        let repo = make_repo("Test");
        let mut entry = make_entry();
        entry.platforms = Some(vec!["linux*".to_string()]);
        assert!(should_activate_repo(&repo, &entry, &rdata("linux", "x86_64", "4.4.0")).unwrap());
    }

    #[test]
    fn activate_platform_glob_no_match() {
        let repo = make_repo("Test");
        let mut entry = make_entry();
        entry.platforms = Some(vec!["macos*".to_string()]);
        assert!(!should_activate_repo(&repo, &entry, &rdata("linux", "x86_64", "4.4.0")).unwrap());
    }

    #[test]
    fn activate_platform_with_distro_matches() {
        let repo = make_repo("Test");
        let mut entry = make_entry();
        entry.platforms = Some(vec!["linux-ubuntu*".to_string()]);
        let mut rd = rdata("linux", "x86_64", "4.4.0");
        rd.distro = Some("ubuntu".to_string());
        rd.release = Some("22.04".to_string());
        assert!(should_activate_repo(&repo, &entry, &rd).unwrap());
    }

    #[test]
    fn activate_platform_with_distro_no_match() {
        let repo = make_repo("Test");
        let mut entry = make_entry();
        entry.platforms = Some(vec!["linux-ubuntu*".to_string()]);
        let mut rd = rdata("linux", "x86_64", "4.4.0");
        rd.distro = Some("fedora".to_string());
        rd.release = Some("42".to_string());
        assert!(!should_activate_repo(&repo, &entry, &rd).unwrap());
    }

    #[test]
    fn activate_manylinux_compat_matches_manylinux_install() {
        // The P3M-manylinux repo is compatible with (can be activated on) any
        // glibc Linux install, including manylinux user-mode installs.
        let repo = make_repo("P3M-manylinux");
        let mut entry = make_entry();
        entry.platforms = Some(vec!["*-linux-gnu-*".to_string()]);
        let mut rd = rdata("x86_64-pc-linux-gnu", "x86_64", "4.4.0");
        rd.distro = Some("manylinux".to_string());
        rd.release = Some("2.34".to_string());
        assert!(should_activate_repo(&repo, &entry, &rd).unwrap());
    }

    #[test]
    fn activate_manylinux_compat_matches_distro_install() {
        // It is also compatible with a regular distro install, so that it can be
        // enabled there on request (it is just not a default there).
        let repo = make_repo("P3M-manylinux");
        let mut entry = make_entry();
        entry.platforms = Some(vec!["*-linux-gnu-*".to_string()]);
        let mut rd = rdata("x86_64-pc-linux-gnu", "x86_64", "4.4.0");
        rd.distro = Some("ubuntu".to_string());
        rd.release = Some("22.04".to_string());
        assert!(should_activate_repo(&repo, &entry, &rd).unwrap());
    }

    #[test]
    fn activate_arch_matches() {
        let repo = make_repo("Test");
        let mut entry = make_entry();
        entry.archs = Some(vec!["x86_64".to_string()]);
        assert!(should_activate_repo(&repo, &entry, &rdata("linux", "x86_64", "4.4.0")).unwrap());
    }

    #[test]
    fn activate_arch_no_match() {
        let repo = make_repo("Test");
        let mut entry = make_entry();
        entry.archs = Some(vec!["aarch64".to_string()]);
        assert!(!should_activate_repo(&repo, &entry, &rdata("linux", "x86_64", "4.4.0")).unwrap());
    }

    #[test]
    fn activate_rversion_constraint_satisfied() {
        let repo = make_repo("Test");
        let mut entry = make_entry();
        entry.rversions = Some(vec![">= 4.0".to_string()]);
        assert!(should_activate_repo(&repo, &entry, &rdata("linux", "x86_64", "4.4.0")).unwrap());
    }

    #[test]
    fn activate_rversion_constraint_not_satisfied() {
        let repo = make_repo("Test");
        let mut entry = make_entry();
        entry.rversions = Some(vec!["< 3.5".to_string()]);
        assert!(!should_activate_repo(&repo, &entry, &rdata("linux", "x86_64", "4.4.0")).unwrap());
    }

    #[test]
    fn activate_all_constraints_must_pass() {
        let repo = make_repo("Test");
        let mut entry = make_entry();
        entry.platforms = Some(vec!["linux*".to_string()]);
        entry.archs = Some(vec!["aarch64".to_string()]); // won't match x86_64
        entry.rversions = Some(vec![">= 4.0".to_string()]);
        assert!(!should_activate_repo(&repo, &entry, &rdata("linux", "x86_64", "4.4.0")).unwrap());
    }

    // --- enabled_by_default ---

    fn manylinux_platform() -> String {
        let mut rd = rdata("x86_64-pc-linux-gnu", "x86_64", "4.4.0");
        rd.distro = Some("manylinux".to_string());
        rd.release = Some("2.34".to_string());
        rdata_platform_string(&rd)
    }

    fn ubuntu_platform() -> String {
        let mut rd = rdata("x86_64-pc-linux-gnu", "x86_64", "4.4.0");
        rd.distro = Some("ubuntu".to_string());
        rd.release = Some("22.04".to_string());
        rdata_platform_string(&rd)
    }

    #[test]
    fn enabled_always() {
        assert!(enabled_by_default(
            &Enabled::Always(true),
            &ubuntu_platform(),
            "Test"
        ));
        assert!(!enabled_by_default(
            &Enabled::Always(false),
            &ubuntu_platform(),
            "Test"
        ));
    }

    #[test]
    fn enabled_on_platforms_default_on_manylinux() {
        // P3M-manylinux is a default on manylinux installs ...
        let enabled = Enabled::OnPlatforms {
            platforms: vec!["*-linux-gnu-manylinux-*".to_string()],
        };
        assert!(enabled_by_default(
            &enabled,
            &manylinux_platform(),
            "P3M-manylinux"
        ));
    }

    #[test]
    fn enabled_on_platforms_optional_on_other_linux() {
        // ... but only optional (off by default) on other glibc Linux installs.
        let enabled = Enabled::OnPlatforms {
            platforms: vec!["*-linux-gnu-manylinux-*".to_string()],
        };
        assert!(!enabled_by_default(
            &enabled,
            &ubuntu_platform(),
            "P3M-manylinux"
        ));
    }

    // --- should_include_repo ---
    // Regression tests for https://github.com/r-lib/rig/issues/369:
    // a blacklisted repo (e.g. `--without-p3m`) must be excluded even when
    // it is enabled by default.

    #[test]
    fn blacklisted_repo_excluded_even_if_enabled_by_default() {
        let setup = ReposSetupArgs::Default {
            whitelist: vec![],
            blacklist: vec!["p3m".to_string()],
        };
        assert!(!should_include_repo(&setup, "P3M", true));
    }

    #[test]
    fn blacklisted_repo_excluded_even_if_whitelisted() {
        // whitelist + blacklist for the same repo: blacklist wins.
        let setup = ReposSetupArgs::Default {
            whitelist: vec!["p3m".to_string()],
            blacklist: vec!["p3m".to_string()],
        };
        assert!(!should_include_repo(&setup, "P3M", false));
    }

    #[test]
    fn non_blacklisted_repo_included_if_enabled_by_default() {
        let setup = ReposSetupArgs::Default {
            whitelist: vec![],
            blacklist: vec!["p3m".to_string()],
        };
        assert!(should_include_repo(&setup, "CRAN", true));
    }

    #[test]
    fn non_default_repo_included_if_whitelisted() {
        let setup = ReposSetupArgs::Default {
            whitelist: vec!["bioc".to_string()],
            blacklist: vec![],
        };
        assert!(should_include_repo(&setup, "BioC", false));
    }

    #[test]
    fn non_default_repo_excluded_if_not_whitelisted() {
        let setup = ReposSetupArgs::Default {
            whitelist: vec![],
            blacklist: vec![],
        };
        assert!(!should_include_repo(&setup, "BioC", false));
    }

    #[test]
    fn empty_mode_only_includes_whitelisted() {
        let setup = ReposSetupArgs::Empty {
            whitelist: vec!["cran".to_string()],
        };
        assert!(should_include_repo(&setup, "CRAN", true));
        assert!(!should_include_repo(&setup, "P3M", true));
    }
}
