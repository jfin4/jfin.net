#![cfg(target_os = "macos")]
#![allow(dead_code)]

use std::alloc::System;
use std::error::Error;
use std::sync::Mutex;

// Otherwise C cannot free() the returned strings

#[global_allocator]
static GLOBAL: System = System;

use lazy_static::lazy_static;
use simple_error::bail;

mod alias;
mod args;
mod built;
mod cache;
mod common;
mod config;
mod dcf;
mod download;
mod escalate;
mod hardcoded;
mod install;
mod library;
mod macos;
mod output;
mod pager;
mod pkg;
mod pkgsource;
mod platform;
mod proj;
mod rds;
mod renv;
mod repos;
mod repositories;
mod resolve;
mod rproj;
mod run;
mod rvenv;
mod rversion;
mod solver;
mod textfmt;
mod utils;
use common::*;
use library::*;
use macos::*;

// ------------------------------------------------------------------------

lazy_static! {
    static ref LAST_ERROR: Mutex<String> = Mutex::new(String::from(""));
    static ref LAST_ERROR2: Mutex<i32> = Mutex::new(0);
}

static SUCCESS: libc::c_int = 0;
static ERROR_NO_DEFAULT: libc::c_int = -1;
static ERROR_DEFAULT_FAILED: libc::c_int = -2;
static ERROR_BUFFER_SHORT: libc::c_int = -3;
static ERROR_SET_DEFAULT_FAILED: libc::c_int = -4;
static ERROR_INVALID_INPUT: libc::c_int = -5;

// ------------------------------------------------------------------------

// Caller must free this

#[no_mangle]
pub extern "C" fn rig_last_error(ptr: *mut libc::c_char, size: libc::size_t) -> libc::c_int {
    let str: String = match LAST_ERROR.try_lock() {
        Ok(x) => x.to_owned(),
        Err(_) => "Unknown error".to_string(),
    };

    let str2 = if size <= str.len() {
        str[..(size - 1)].to_string() + "\0"
    } else {
        str.to_string()
    };
    match set_c_string(&str2, ptr, size) {
        Ok(x) => x,
        Err(_) => ERROR_BUFFER_SHORT,
    }
}

fn set_error(str: &str) {
    match LAST_ERROR.try_lock() {
        Ok(mut x) => {
            x.clear();
            x.insert_str(0, str);
        }
        Err(_) => {
            // cannot save error message, not much we can do
        }
    };
}

fn set_c_string(
    from: &str,
    ptr: *mut libc::c_char,
    size: libc::size_t,
) -> Result<libc::c_int, Box<dyn Error>> {
    let from = from.to_string() + "\0";
    let bts = from.as_bytes();
    let n = from.len();
    if n <= size {
        let ptr2;
        unsafe {
            ptr2 = std::slice::from_raw_parts_mut(ptr as *mut u8, size);
        }
        ptr2[0..n].clone_from_slice(bts);
        Ok(SUCCESS)
    } else {
        bail!("String buffer too short")
    }
}

fn set_c_strings(
    from: Vec<String>,
    ptr: *mut libc::c_char,
    size: libc::size_t,
) -> Result<libc::c_int, Box<dyn Error>> {
    let mut n = from.len() + 1; // terminating \0 plus ultimate temrinating \0
    for s in &from {
        n += s.len();
    }
    if n <= size {
        let mut idx = 0;
        let ptr2;
        unsafe {
            ptr2 = std::slice::from_raw_parts_mut(ptr as *mut u8, size);
        }
        for s in &from {
            let l = s.len();
            ptr2[idx..(idx + l)].clone_from_slice(s.as_bytes());
            idx += l;
            ptr2[idx] = 0;
            idx += 1;
        }
        ptr2[idx] = 0;
        Ok(SUCCESS)
    } else {
        bail!("String buffer too short")
    }
}

// ------------------------------------------------------------------------

// The installation mode rig is configured for ("user" or "admin"). The menu
// bar app has no shell environment, so it cannot see RIG_MODE, but
// get_mode() also reads the `mode` key of the rig config file, which is
// where `rig system user-mode` records it.

#[no_mangle]
pub extern "C" fn rig_mode(ptr: *mut libc::c_char, size: libc::size_t) -> libc::c_int {
    match utils::get_mode() {
        Ok(mode) => match set_c_string(&mode.to_string(), ptr, size) {
            Ok(x) => x,
            Err(_) => {
                set_error("Buffer too short for rig mode");
                ERROR_BUFFER_SHORT
            }
        },
        Err(e) => {
            let msg = e.to_string();
            set_error(&msg);
            ERROR_DEFAULT_FAILED
        }
    }
}

// The directory the R versions are installed into. This is
// /Library/Frameworks/R.framework/Versions in admin mode and
// ~/.local/share/rig/r in user mode. The app watches it for changes.

#[no_mangle]
pub extern "C" fn rig_r_root(ptr: *mut libc::c_char, size: libc::size_t) -> libc::c_int {
    match get_r_root() {
        Ok(root) => match set_c_string(&root, ptr, size) {
            Ok(x) => x,
            Err(_) => {
                set_error("Buffer too short for R root directory");
                ERROR_BUFFER_SHORT
            }
        },
        Err(e) => {
            let msg = e.to_string();
            set_error(&msg);
            ERROR_DEFAULT_FAILED
        }
    }
}

#[no_mangle]
pub extern "C" fn rig_get_default(ptr: *mut libc::c_char, size: libc::size_t) -> libc::c_int {
    let def = sc_get_default();

    match def {
        Ok(x) => match x {
            Some(xx) => match set_c_string(&xx, ptr, size) {
                Ok(x) => x,
                Err(_) => {
                    set_error("Buffer too short for R version");
                    ERROR_BUFFER_SHORT
                }
            },
            None => {
                set_error("No default R version is set currently");
                ERROR_NO_DEFAULT
            }
        },
        Err(e) => {
            let msg = e.to_string();
            set_error(&msg);
            ERROR_DEFAULT_FAILED
        }
    }
}

#[no_mangle]
pub extern "C" fn rig_list(ptr: *mut libc::c_char, size: libc::size_t) -> libc::c_int {
    let vers = sc_get_list();

    match vers {
        Ok(x) => match set_c_strings(x, ptr, size) {
            Ok(x) => x,
            Err(_) => {
                set_error("Buffer too short for R version");
                ERROR_BUFFER_SHORT
            }
        },
        Err(e) => {
            let msg = e.to_string();
            set_error(&msg);
            ERROR_DEFAULT_FAILED
        }
    }
}

#[no_mangle]
pub extern "C" fn rig_list_with_versions(
    ptr: *mut libc::c_char,
    size: libc::size_t,
) -> libc::c_int {
    let vers = sc_get_list_details();

    match vers {
        Ok(x) => {
            let mut vers: Vec<String> = vec![];
            for it in x {
                let r = it.name + "|" + &it.version.unwrap_or("".to_string());
                vers.push(r)
            }
            match set_c_strings(vers, ptr, size) {
                Ok(x) => x,
                Err(_) => {
                    set_error("Buffer too short for R version");
                    ERROR_BUFFER_SHORT
                }
            }
        }
        Err(e) => {
            let msg = e.to_string();
            set_error(&msg);
            ERROR_DEFAULT_FAILED
        }
    }
}

#[no_mangle]
#[allow(clippy::not_unsafe_ptr_arg_deref)]
pub extern "C" fn rig_set_default(ptr: *const libc::c_char) -> libc::c_int {
    let cver;

    unsafe {
        cver = std::ffi::CStr::from_ptr(ptr);
    }

    let ver = match cver.to_str() {
        Ok(x) => x,
        Err(_) => return ERROR_INVALID_INPUT,
    };

    match sc_set_default(ver) {
        Ok(_) => SUCCESS,
        Err(e) => {
            let msg = e.to_string();
            set_error(&msg);
            ERROR_SET_DEFAULT_FAILED
        }
    }
}

#[no_mangle]
#[allow(clippy::not_unsafe_ptr_arg_deref)]
pub extern "C" fn rig_start_rstudio(
    pversion: *const libc::c_char,
    pproject: *const libc::c_char,
) -> libc::c_int {
    let cver;
    let cprj;

    unsafe {
        cver = std::ffi::CStr::from_ptr(pversion);
        cprj = std::ffi::CStr::from_ptr(pproject);
    }

    let ver = match cver.to_str() {
        Ok(x) => x,
        Err(_) => {
            return ERROR_INVALID_INPUT;
        }
    };

    let prj = match cprj.to_str() {
        Ok(x) => x,
        Err(_) => {
            return ERROR_INVALID_INPUT;
        }
    };

    let ver = if ver.is_empty() {
        None
    } else {
        Some(ver.to_string())
    };
    let prj = if prj.is_empty() {
        None
    } else {
        Some(prj.to_string())
    };

    match sc_rstudio2(ver.as_ref(), prj.as_ref()) {
        Ok(_) => SUCCESS,
        Err(e) => {
            let msg = e.to_string();
            set_error(&msg);
            ERROR_SET_DEFAULT_FAILED
        }
    }
}

#[no_mangle]
pub extern "C" fn rig_library_list(ptr: *mut libc::c_char, size: libc::size_t) -> libc::c_int {
    let vers = sc_library_get_list(None, true);

    match vers {
        Ok(x) => {
            let mut vers: Vec<String> = vec![];
            for it in x {
                let nm = it.name + if it.default { "*" } else { "" };
                vers.push(nm)
            }
            match set_c_strings(vers, ptr, size) {
                Ok(x) => x,
                Err(_) => {
                    set_error("Buffer too short for R libraries");
                    ERROR_BUFFER_SHORT
                }
            }
        }
        Err(e) => {
            let msg = e.to_string();
            set_error(&msg);
            ERROR_DEFAULT_FAILED
        }
    }
}

#[no_mangle]
#[allow(clippy::not_unsafe_ptr_arg_deref)]
pub extern "C" fn rig_lib_set_default(ptr: *const libc::c_char) -> libc::c_int {
    let cver;

    unsafe {
        cver = std::ffi::CStr::from_ptr(ptr);
    }

    let ver = match cver.to_str() {
        Ok(x) => x,
        Err(_) => return ERROR_INVALID_INPUT,
    };

    match sc_library_set_default(ver, None) {
        Ok(_) => SUCCESS,
        Err(e) => {
            let msg = e.to_string();
            set_error(&msg);
            ERROR_SET_DEFAULT_FAILED
        }
    }
}
