Remove R versions [aliases: del, remove, delete]

## Description

Remove an R installation. It keeps the users' package libraries.

In [user mode](../admin-vs-user-mode.qmd) no administrator rights are needed. In admin mode you need an
administrator account to run this command or use `sudo` on Unix, otherwise
rig will ask for your password.
