Print the directories rig uses

## Description

Print the directories rig uses: where R and (on Windows) Rtools is
installed, where the quick links are created, where (on Linux) rig keeps
the fontconfig configuration and the fallback fonts of the portable R
builds, where rig downloads the installers to, where rig keeps its own
configuration, data, cache and log files, and the root `rig proj`
centralizes project package libraries under, if configured.

The directories themselves may not exist.

Use `--json` for machine-readable output.

The output contains the directories in effect. They may be the defaults, or
configured via the rig config file or environment variables.

Some directories may depend on the mode and on the architecture, e.g. on
aarch64 Windows the R installation directory is different for aarch64 and
x86_64 R builds.

Use `--user` and `--admin` to override the mode for a single invocation.

## Printing a single directory

With one of the flags (see below) rig prints that single directory as a
bare path, and nothing else, for use in a shell script:

```
cd "$(rig system dirs --r)"
```

The flags are mutually exclusive, and cannot be combined with `--json`.

`--r` is the directory that *contains* the directories of the individual R
versions; it is not an R installation itself. Similarly `--rtools` is the
directory that contains the Rtools directories. Use `rig list --json` and `rig
rtools list` for the paths of the installed versions.

The Rtools installation root is only reported on Windows. On non-Windows
platforms `--rtools` prints nothing and is hidden.

The fontconfig directory is only reported on Linux, where it holds the
`fonts.conf` and the fallback fonts that rig installs for the portable R
builds. On non-Linux platforms `--fonts` prints nothing and is hidden.

`--download` is the directory rig downloads the installers into. It is in the
system temporary directory and its name contains your user id, so that
[admin and user mode](../admin-vs-user-mode.qmd) installs, and different users of the same machine,
never share it. See the `download-dir` [configuration entry](config.qmd) to change it.

`--library-root` is the root [`rig proj sync`](proj.qmd#rig-proj-sync)
centralizes project package libraries under, if the `RIG_PROJ_LIBRARY_ROOT`
environment variable or the `proj-library-root` [configuration
entry](config.qmd) is set. Unset by default: each project's library then
stays at its own `.rvenv/lib`, and `--library-root` prints that fact instead
of a path.
