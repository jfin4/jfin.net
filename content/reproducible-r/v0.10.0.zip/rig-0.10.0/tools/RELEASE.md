
- [ ] Make sure README has the correct command list.
- [ ] Make sure version number is updated everywhere:
  - Cargo.toml
  - Cargo.lock (run cargo build)
  - rig.iss
  - choco/rig/rig.nuspec
  - NEWS file
  - website/install.ps1
  - website/install.sh
- [ ] If needed, commit to have a CI build with the right version number.
- [ ] Make sure CI is OK
- [ ] Build README:
  ```
  Rscript -e 'rmarkdown::render("README.Rmd")'
  ```
- [ ] Update NEWS header to remove `(not released yet)`
- [ ] Build signed and notarized macOS packages locally:
  ```
  export AC_PASSWORD=...
  export TEAM_ID=...
  sudo xcode-select -s /Applications/Xcode.app/Contents/Developer
  rm -rf target
  make clean
  make macos
  ```
  (https://github.com/mitchellh/gon is now archived, I had to compile my
  own fork, from https://github.com/UniversalMediaServer.)
- [ ] Get the signed Windows builds from SignPath:
  - Run the `sign-windows.yaml` Action manually (`workflow_dispatch`),
    selecting the `release-signing` signing policy. It builds and signs
    both the x86_64 and aarch64 installers.
  - Approve each signing request in the SignPath UI if prompted.
  - Download the `rig-windows-x86_64-signed` and `rig-windows-aarch64-signed`
    artifacts from the workflow run; use these signed `.exe` files for the
    release (not the unsigned CI artifacts). Rename them to
    `rig-windows-${VERSION}.exe` and `rig-windows-arm64-${VERSION}.exe`.
- [ ] Download the artifacts for the new version for Linux (x2)
- [ ] Create tag for the current version, push to GH.
- [ ] Create the release on GH **as a draft** (`gh release create --draft ...`
      or the GH UI), and add all the installers to the draft.
- [ ] Test the macOS installers. (The rest are tested in the CI.)
- [ ] Once every installer is attached, publish the draft release
      (`gh release edit <tag> --draft=false`, or the "Publish release"
      button in the GH UI).
- [ ] `git commit` with the NEWS and README updates, update tag, push to GH,
      `--tags` as well.
- [ ] Update Debian repo, by running the Action manually, and then check out
      the `gh-pages` branch (into another directory, probably), add the
      dokku remote, cherry-pick the updates from the dokku remote, and
      then force-push to the server at DigitalOcean.
      The purge the cloudflare cache for rig.r-pkg.org.
- [ ] Update homebrew repo.
- [ ] Update choco package.
    - Make sure `rig.nuspec` is current
	- `choco pack`
	- Delete old `.nupkg` file
	- Test:
	  ```
	  gsudo choco uninstall rig
	  gsudo choco install rig --source .
	  rig --version
	  rig ls
	  rig available
	  ```
	- Submit:
	  ```
	  choco push rig.*.nupkg --source https://push.chocolatey.org/
	  ```
- [ ] Submit update to winget-pkgs:
    ```
    VERSION=x.y.z
    komac update --version "$VERSION" \
    --urls "https://github.com/r-lib/rig/releases/download/v${VERSION}/rig-windows-${VERSION}.exe" \
    --submit 'Posit.rig'
    ```
- [ ] Update the `latest` tag and release on GH.
- [ ] toot
