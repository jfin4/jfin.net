**Multiple R versions, side by side**

* Install as many R versions as you like, and switch the default for the
  terminal, RStudio and Positron.
* Select versions by symbolic name: `release`, `devel`, `next`, `oldrel`,
  or by exact version.
* Run several versions _at the same time_ via quick links: `R-4.5` or
  `R-4.5.1` starts the matching R. Quick links are added to your path
  automatically.
* List the versions you have installed, and the versions available to
  install.
* On arm64 macs and Windows, choose between x86_64 and arm64 builds of R,
  or install both.

**Cross-platform and self-contained**

* Works on macOS, Windows and Linux. Has native builds for many
  [Linux distributions](install.qmd#id-supported-linux-distributions), and
  portable builds that run on any glibc- or musl-based Linux.
* A single standalone tool with no system requirements. Easy to install
  and update on every platform.
* Two [installation modes](admin-vs-user-mode.qmd): the default
  *admin mode* installs R system-wide (elevating to root/administrator only
  when needed), while the newer *user mode* installs everything into your
  home directory with no `sudo` or administrator rights.
* On Linux, installs distro-specific builds where available, and otherwise
  falls back to portable glibc/musl builds automatically.

**Package management, set up for you**

* Configures the default CRAN mirror and
  [PPM](https://packagemanager.posit.co/) binary repositories.
* Installs [pak](https://pak.r-lib.org) and enables automatic
  [system requirements installation](https://pak.r-lib.org/dev/reference/sysreqs.html).
* Creates and configures per-user package libraries.
* [`rig repos`](reference/repos.qmd) manages package repositories across
  all your R versions.
* [`rig pkg`](reference/pkg.qmd) (experimental) installs, removes and lists
  packages in a library, and looks up package info, dependencies and
  dependency trees from the repositories, all without running R.

**Project dependency management (experimental)**

* [`rig proj`](reference/proj.qmd) manages an R project through an
  `rproj.toml` manifest: add or remove dependencies, resolve them with
  rig's built-in solver into an `rproj.lock` lockfile, and sync a project
  library to match, all without running R.
* Import a project from, or export it to, a `DESCRIPTION` file or an
  [renv](https://rstudio.github.io/renv/) `renv.lock` file, to interoperate
  with existing R package and project tooling.
* Inspect a project's dependencies and dependency tree before installing.

**Run R, scripts and apps**

* `rig run` starts R, runs a script or expression, or launches an app:
  Shiny apps, Plumber APIs, Quarto and R Markdown documents, and static
  sites, with the R version you choose.

**Platform niceties**

* A [macOS menu bar app](macos-app.qmd) shows the default R version and
  lets you switch it interactively.
* Installs and configures the right Rtools versions on Windows, and cleans
  up stale R entries from the Windows registry.
* Shell auto-completion for `zsh` and `bash` on macOS and Linux, and for
  PowerShell on Windows.
* On macOS, sets up R for debugging with `lldb` and enables core dumps.
* JSON output for scripting, and a `rig config` command to manage rig's
  own configuration.
