# rig 0.10.0

## Web site

* rig has a new documentation website at <https://rig.r-lib.org/>,
  including a full CLI reference and a guide to admin vs. user mode.

## User mode

* rig now supports a **user mode** on all platforms, in addition to the
  default admin mode. In user mode rig installs everything into the user's
  home directory and never needs `sudo` or administrator privileges. R goes
  into `~/.local/share/rig/r` (`%APPDATA%\rig\data\r` on Windows) and quick
  links into `~/.local/bin` (`%USERPROFILE%\.local\bin` on Windows). Select
  the mode with the `--user` / `--admin` global flags, the `RIG_MODE`
  environment variable, or the `mode` key in the rig config file. The new
  `rig system user-mode` command switches an existing admin-mode setup to
  user mode.

* On Linux, rig can now install portable R builds, for glibc- and
  musl-based Linux distros. If there is no distro-specific build for your
  platform, rig falls back to a portable build automatically.

## R package management

* New `rig pkg` subcommand to query and manage R packages. Two subcommands
  from `rig repos` moved to `rig pkg`: `rig pkg available` and
  `rig pkg info`. `rig pkg deps` lists the packages a package needs, in a
  table, and `rig pkg tree` shows the same dependencies as a tree.
  `rig pkg list` lists the packages installed in a library,
  `rig pkg remove` deletes packages from a library, and
  `rig pkg install` installs packages, and their dependencies, into a
  library.

## Projects

* New and redesigned `rig proj` commands to manage isolated R projects and
  virtual environments: `rig proj init`, `rig proj import`, `rig proj add`,
  `rig proj remove`, `rig proj lock`, `rig proj sync`, `rig proj status`.

* New `rig proj tree` shows the dependency closure of a project as a tree.

* `rig run` now uses the project environment, if you call it in a project
  directory: it starts `.rvenv/bin/R`, with the project's package library
  and the R version the project's lock file names, and it syncs the project
  first if the environment is missing or out of date. Use `--no-project`
  (or `--r-version`) to run the default R version instead.

* `rig run <name>` now runs a script the project declares in a `[[bin]]`
  table of its `rproj.toml`, passing the remaining arguments on to the
  script. `rig run --list` lists the declared scripts.

* `rig proj sync` can now centralize project package libraries outside the
  project directory: set the `RIG_PROJ_LIBRARY_ROOT` environment variable or
  the `proj-library-root` config key to a root directory, and each project
  gets its own library under it, keyed by project name and location. A
  compatibility symlink is left at the project's usual `.rvenv/lib`. `rig
  system dirs --library-root` reports the effective root (#372).

## Windows specific

* Windows builds of rig are now signed, thanks to the SignPath Foundation,
  https://signpath.org/.

* On Windows rig now creates `.exe` shims instead of `bat` shims.
  With `.exe` shims it is easier to pass command line arguments to
  `R` and `Rscript`. In particular, `Rscript -e <code>` now works if
  `<code>` has line breaks. Call `rig system make-links` to create all
  `.exe` shims and remove the `.bat` shims. If you hardcoded shims with
  a `.bat` extension, change them to `.exe` or remove the extension
  completely (#362).

* New `rig system fix-r-alias` subcommand.

* `rig rtools` is now a top-level command (it used to be `rig system
  rtools`).

* On Windows, `R CMD config` now works without manually putting Rtools on
  the `PATH`. So do `R CMD sh`, `R CMD make` and `rig run --cmd config`.

## macOS specific

* `rig sysreqs` has been removed. It did not reliably set up a working
  Fortran toolchain (#262). Install gfortran from
  <https://mac.r-project.org/tools> instead.

## Other new features

* `rig add` no longer reinstalls a version that is already installed,
  except for R-devel and R-next. Use `--reinstall` for force a re-install
  (#293).

* `rig add` can now install the R version an `renv.lock` file requires,
  e.g. `rig add renv.lock` or `rig add path/to/renv.lock` (#294).

* New `rig system blas` commands, to check and switch which BLAS/LAPACK
  library an installed R version uses on macOS, e.g. to switch to Apple's
  faster Accelerate/vecLib BLAS (#212).

* New `rig self update` to update rig, new `rig self uninstall` to remove
  rig, if it was installed via the install script.

* New `rig cache` command to inspect and manage rig's download and build
  caches. rig now reflinks or hardlinks packages from the cache when
  possible, instead of copying them, to save disk space and time.

* New `rig ppm` command queries Posit Package Manager. New `rig ppm
  build-log` shows the build log of a package on Posit Package Manager.

* New `rig repos status` checks the configured package repositories.

* New `rig system fix-aliases` to update `R-release`, `R-oldrel` etc.
  aliases (#234).

* `rig library add`, `rig library default`, `rig library list` and
  `rig library rm` have a new `--r-version` (`-r`) option, to operate on
  the libraries of an R version other than the default one.

* New `rig system dirs` command to show the directories rig uses. With
  `--r`, `--binary`, `--data`, `--cache`, `--download`, `--log`, `--rtools`
  (Windows only) or `--fonts` (Linux only) it prints a single path, for use
  in scripts.

* New `rig config` command to manage the rig configuration file.

* `rig run --cmd <command> [args...]` now runs `R CMD <command> [args...]`
  with the selected R version.

* `rig run -- <flags>` now passes raw arguments straight to the R process,
  e.g. `rig run -- --vanilla` or `rig run -e '1+1' -- --vanilla` (#249).

* Plain `rig run` (i.e. without `-e`/`-f`/an app/`--cmd`) now defaults to
  `--no-save --no-restore`, so it no longer shows the "Save workspace
  image?" prompt on exit. Use `rig run -- --save --restore` to get the old
  behavior back (#249).

## Other changes

* `rig add --without-p3m` works correctly again (#369).

* macOS user mode: `rig default` now sets the default R version correctly
  for newer RStudio versions. Also, `rig system allow-debugger-rstudio`
  now works for newer RStudio versions.

* rig now uses a user-dependent download directory, to avoid interference
  between users.

* rig now does not edit the shell startup files in admin mode,
  like rig 0.8.1 did on macOS. rig now only does this in user mode.

* `rig repos available` now prints a compact table. New
  `rig repos available <name>` shows complete information about a single
  repository.

* `rig system setup-user-lib` (and its `create-lib` alias) now works again.

* `rig rstudio --config-path` is now implemented on Linux and macOS.

* rig now warns instead of failing when it encounters a broken R
  installation (#346).

# rig 0.8.1

* The `RIG_PLATFORM` environment variable works correctly again (#325).

* rig can now install R > 4.6.0 (current R-devel) correctly on macOS.

# rig 0.8.0

* New `rig repos` subcommand to manage R package repository setup
  across all installed R versions.

* The `--without-p3m` option of `rig add` is now always available, for
  consistency across platforms. By default P3M is on on x86_64 Windows and
  supported Linux distros, as before. The new `--with-p3m` option turns
  on P3M on macOS as well.

* rig now supports aarch64 Windows. It currently only supports installing
  aarch64 builds of R and Rtools on aarch64 Windows. The x86_64 build of
  rig also works on aarch64 Windows and installs aarch64 builds of R and
  Rtools. Installing and managing x86_64 builds of R on aarch64 Windows is
  not supported yet.

* rig now supports RHEL 10 and binary compatible distributions like
  AlmaLinux OS 10 and Rocky Linux 10.

* R installations by rig now do *not* set the default CRAN repositories in
  RStudio and Positron (#203).

* rig now supports the new macOS arm64 Sonoma builds, which are are the default
  CRAN builds starting from R 4.6.0 (current R-devel).

# rig 0.7.1

* macOS packages now include completion files for elvish and fish shells
  (#221, @TymekDev).

* `rig available --list-distros` output now includes PPM support, whether
  the a distro is retired, the EOL and in the JSON format also the last
  R version for that distro.

* `rig add` is now better at detecting PPM support for new Linux
  distribution versions. In particular, new Linux distribution releases
  do not need a rig update to learn about PPM support. Relatedly,
  `rig system detect-platform` now does **not** report PPM support.
  Use `rig available --list-distros` to see which Linux distributions have
  PPM binaries.

* `rig run` now exits with the exit code of the R process (#261).

* Custom certificates via the `SSL_CERT_FILE` environment variable
  work again (#227).

* `rig library default` does not crash now (#240).

* rig now uses a better way to get the user's home directory, that works
  on systems without an `/etc/passwd` database (#228).

* Windows: rig supports Rtools45 now.

# rig 0.7.0

* Bash completions work well again (#202).

* `rig rstudio` has a new implementation that works much better.
  Now it always defaults to the R version in `renv.lock` for renv
  projects, and can open RStudio projects or directories.

* New `rig available --list-rtools-versions` option to list available
  Rtools versions.

* `rig run` now does not terminate the rig process on interrupts
  (CTRL+C, CTRL+BREAK on Windows, SIGINT on Unix) (#187).

* Windows: new `rig system rtools` subcommand to add, remove, list
  Rtools versions (#18).

* Windows: rig now supports Rtools44 on Windows.

* Windows: rig now defaults to Rtools42 for R 4.2.x on Windows.

* macOS: `rig rstudio <version>` works again on recent macOS versions (#208).

* macOS: rig now always creates the `/usr/local/bin/R-*` quick links
  with 0755 permissions (#200).

* Linux: `rig add --without-p3m` works again (#193).

* Linux: `RIG_PLATFORM` works again when `sudo` is needed (#191).

# rig 0.6.0

* rig now supports RPM based distros, in addition to Debian and Ubuntu (#28).
  The full list of supported distros, on x86_64 and aarch64:
  - Debian 10, 11, 12,
  - Ubuntu 18.04, 20.04, 22.04,
  - Fedora Linux 37, 38,
  - OpenSUSE 15.3, 15.4,
  - SUSE Linux Enterprise 15 SP3, SP4,
  - CentOS 7,
  - Red Hat Enterprise Linux 7, 8, 9,
  - AlmaLinux 8, 9,
  - Rocky Linux 8, 9.
  See also the new `rig available --list-distros`.

* New `rig available` command to list R versions available to install.
  `rig available --list-distros` lists the supported Linux distributions.

* New `rig run` to run R, an R script or an R project, using the selected
  R version (#161).

* rig now works in a shell that is a subprocess or R, e.g. in the
  RStudio terminal (#127).

* rig now works behind a proxy, on macOS and Linux, if the `https_proxy`
  environment variable is set (#166).

* `rig resolve` now has a `--platform` and a `--arch` arguments, to look up
  available R versions for any supported platform, instead of the current
  one.

* `rig ls --plain` lists only the R version names, this is useful in
  shell scripts (#128).

* `rig rstudio` now starts RStudio with the correct working directory
  and project (#139, #100).

* macOS: `rig add` now only changes the permission for the R version
  that it is installing (#109).

* Windows: `rig rstudio` now starts the correct R version, even with newer
  RStudio versions (#134).

* Windows: rig now works in PowerShell 7.

* Windows: the rig installer now does not create shortcut in the start
  menu (#160).

* Linux and macOS: rig now keeps the locales when switching to the root
  user, so e.g. the language does not change (#138).

* Linux: rig now works properly in Oh My Zsh (#125).

* Linux: rig now works around a missing `/usr/bin/sed` that happened
  on some distros (#119).

* Linux: rig now does not fail if the default R version was deleted (#124).

* Linux: new subcommand `rig system detect-platform` to print the detected
  Linux distribution and configuration.

* Linux: You can now set the `RIG_PLATFORM` environment variable to
  override the auto-detected Linux distriution. E.g.
  `RIG_PLATFORM=ubuntu-22.04` will force Ubuntu 22.04.

* Linux: rig now comes with a CA certificate bundle, so it works without
  system certificates. If you prefer not to use it, set the `SSL_CERT_FILE`
  environment variable to point to your preferred CA bundle (#176).

# rig 0.5.3

* rig can now install x86_64 R 4.3.0 and later on macOS.

* rig now does a better job when resolving R versions.

* rig now supports Rtools43 on Windows.

* rig now does not try to reinstall Rtools if the same version
  is already installed.

# rig 0.5.2

* rig now always runs non-interactively on Linux from a root shell (#117).

* rig now always uses `--vanilla` when running R (#120).

* rig now detects Deepin Linux as Debian (#111).

# rig 0.5.1

* rig now prints output from `apt`, etc. like regular logging output on Linux.

* rig now supports the alises `oldrel`, `release`, `next`, `devel` in
  `rig default`, `rig rm`, `rig rstudio`, etc. (#108).

# rig 0.5.0

* rig can now open renv projects in RStudio, with the correct R version.
  Pass the renv lock file to rig: `rig rstudio .../renv.lock` (#74).

* `rig list` now prints the result as a table, and it prints the R version
  number as well. `rig list --json` includes the version number, the path
  to the installation, and the path to the R binary.

* rig is now more robust when setting up the user library. In
  particular R will not fail to start in renv projects (#81, @krlmlr).

* On macOS and Linux `rig add` now creates the user library with the right
  permissions, if it does not exist and pak is installed (#84).

* `rig add` now correctly installs pak into the user library, instead of
  the system library, even if the user library did not exist before.

## Windows

* On Windows, `rig add ... --without-translations` installs R without
  message translations. This is useful if you prefer using R in
  English on a non-English system (#88).

* On Windows `rig add` does not add a Desktop icon now by default.
  If want an icon, use the new `--with-desktop-icon` switch (#89).

* On Windows, if the default version is deleted, rig updates the
  registry accordingly, and removes the default from there as well (#86).

* New subcommand `rig system update-rtools40` updates MSYS2 packages
  of Rtools40 on Windows (#14).

## macOS

* On macOS `rig add` now does not fail if it is started from an x86_64
  shell, when adding an arm64 R version on M1 Macs (#79).

* On macOS, `rig rstudio <ver>` now errors if R `<ver>` is not orthogonal,
  and the menu bar app errors as well (#90).

# rig 0.4.1

* `rig rstudio <version>` and `rig rstudio <version> <project>` work properly
  again (#77).

* On Windows, `rig rstudio` now properly restores the default version after
  starting RStudio, if a non-default version was specified.

# rig 0.4.0

## NEW NAME

`rim` is now known as `rig`.

## New features

* Experimental multi-library support. See `rig library --help` for the
  details.

* On macOS rig now includes a menu bar app that show the default R version,
  lets you choose between R versions and libraries, and lets you start
  RStudio with a specific R version, and/or a recent RStudio project.
  Start the app with `open -a Rig`.

* New subcommand `rig system setup-user-lib` to update the R config to create
  the user package library when R starts up, if it does not exist. The old
  `rig system create-lib` subcommand is now an alias of this.

* Better messages. rig has a `-v` and `-vv` flag now, for extra debug and
  trace messages.

* On arm64 macOS, `rig add` installs arm64 R by default now.
  (This is also true for the x86_64 build of `rig`.

* On macOS `rig add` does not change the default R version any more (#2).

* rig now supports Linux distros based on Ubuntu Bionic 18.04, Focal 20.04
  and Jammy 22.04. They need to have a proper `UBUNTU_CODENAME` entry in
  `/etc/os-release` (#34).

* rig now sets up automated system requirements installation with pak on Linux
  distributions that support it: Ubuntu 18.04, 20.04 and 22.04 (on distros
  based on these), on both x86_64 and aarch64. (This currently needs
  passwordless `sudo` or a root account.)

* All OSes create an `Rscript` link now that runs the default R
  version (#20).

# rim 0.3.0

* New `rim rstudio` command to open a project in RStudio with the specified
  R version.

* `rim add` now performs additonal tasks, to give you an R installation that
  is ready to use:

  - It installs pak for the newly added R version, it is wasn't
    installed before. You can opt out of this with the `--without-pak` option.
    You can select the pak version to install with `--pak-version`.

  - Sets the default R version after installation to the newly
    installed version, if no default is set.

  - Sets the default CRAN mirror to the cloud mirror in the
    system profile, after installation (#11).

  - Sets up RStudio Package Manager (RSPM) as the default repository, if
    your system is supported. See
    https://packagemanager.rstudio.com for more about RSPM. The systems that
    are supported by both RSPM and rim are Windows, and Ubuntu Linux
    18.04, 20.04 and 22.04, all of them on x86_64 architectures only (#15).

* `rim add` now only caches downloaded files for a day.

* `rim system add-pak` now has a new option `--pak-version` to specify the
  pak version to install (stable, rc or devel). Its `--devel` option is
  now deprecated.

* `rim list` now marks the default R version (if any) with `(default)` (#38).

## Windows

* rim has a Chocolatey package now, so on Windows you can install it with
  `choco install rim` and upgrade it with `choco upgrade rim`.

* On Windows `rim default <version>` now sets the default R version in the
  Windows Registry as well, which changes the default for RStudio.
  (Make sure you set the R version in RStudio to the machine's default
  version in Tools -> Global Options -> Basic -> General -> R version.)

## macOS

* On macOS `rim system fix-permissions` now sets the permissions and group
  of the `Current` link. Also, `rim add` now calls `rim system fix-permissions`
  for all installed R versions, because the R installed changes the
  permissions of all of them.

# rim 0.2.3

* `rim system allow-debugger` and `rim system allow-core-dumps` now work on
  macOS Big Sur.

# rim 0.2.2

* rim now supports the next version of R:
  ```
  rim resolve next
  rim add next
  ```
  The next version of R is R-alpha, R-beta, R-rc or R-prerelease if there
  is an active R release process, and it is R-patched otherwise.

# rim 0.2.1

## Linux

* rim now supports arm64 Linux, currently the following distributions:
  Ubuntu 18.04, 20.04 & 22.04 and Debian 9, 10 & 11.

* rim now supports Debian 11, on arm64 and x86_64.

## macOS

* New macOS `rim system` commands to allow debugging:
  `rim system allow-debugger`; and to allow core dumps:
  `rim system allow-core-dumps`.

* rim now uses better R-devel URLs on macOS, that do not fail if the daily
  build failed on mac.r-project.org.

## Windows

* rim now supports Rtools42 on Windows: `rim add rtools42`.

* Fix resolution of older Windows installers, they were moved to
  another URL.

* rim can now delete Rtools on Windows, e.g.: `rim rm rtools42`.

# rim 0.2.0

* New Linux version.

* On macOS rim now asks for your password for tasks that require admin
  access.

* On Windows rim now automatically elevates to administrator privileges
  as needed, by re-running with gsudo. gsudo is now bundled in the
  Windows distribution.

* New `rim system clean-registry` command to remove leftover Windows
  registry entries

* New `rim system no-openmp` to use the Apple compilers on macOS.

* `rim rm` now cleans the registry on Windows.

* The Windows rim installer adds rim and R to the PATH on GitHub Actions.

* `rim list` does not error any more if no R versions are installed.

* macOS now has `rim system no-openmp` to fix the conpiler configurations
  for the Apple compilers.

# rim 0.1.5

* Experimental Windows version.

# rim 0.1.4

* `resolve` and `add` work again.

# rim 0.1.3

* `bash` and `zsh` completions out of the box, on macOS

* You can now pass URLs `.pkg` installers to `rim add` on macOS.

# rim 0.1.2

* `rim ls` is now a synonym of `rim list`.

* We have macOS installers now, and they are signed and notarized.

# rim 0.1.1

* `rim rm now supports removing multiple versions.

* `rim system` commands `create-lib`, `fix-permissions` and
  `make-orthogonal` can be now restricted to one or more R versions.
  `rim add` now only calls them for the newly installed R version.

* `rim system add-pak` is now implemented.

# rim 0.1.0

First pre-release.
